const _ = require('lodash')

console.log( _.capitalize("hello world!") )
