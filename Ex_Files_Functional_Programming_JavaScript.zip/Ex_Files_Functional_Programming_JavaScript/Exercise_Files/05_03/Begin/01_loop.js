// Learning Functional Programming with Javascript
// Chapter 05, Video 03, Exercise 01

function loop(i) {

}
