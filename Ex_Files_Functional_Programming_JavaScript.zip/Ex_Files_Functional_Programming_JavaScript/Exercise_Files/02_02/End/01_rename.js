// Learning Functional Programming with Javascript
// Chapter 02, Video 02, Exercise 01 **SOLUTION**
var line = console.log

line()
line("Hello and welcome to the course!")
line("We seem to be using")
line("a lot of console.logs here.")
line("Why don't we rename it")
line("to make it look better?")
line("To do that, simply assign the function")
line("'console.log' to another variable.")
line("You can call it whatever you want.")
line("I called mine 'line' to reflect the")
line("way that I'm using it.")
line()
