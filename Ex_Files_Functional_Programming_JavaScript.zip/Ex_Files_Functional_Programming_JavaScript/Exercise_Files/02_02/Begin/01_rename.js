// Learning Functional Programming with Javascript
// Chapter 02, Video 02, Exercise 01

console.log()
console.log("Hello and welcome to the course!")
console.log("We seem to be using")
console.log("a lot of console.logs here.")
console.log("Why don't we rename it")
console.log("to make it look better?")
console.log("To do that, simply assign the function")
console.log("'console.log' to another variable.")
console.log("You can call it whatever you want.")
console.log("I called mine 'line' to reflect the")
console.log("way that I'm using it.")
console.log()
