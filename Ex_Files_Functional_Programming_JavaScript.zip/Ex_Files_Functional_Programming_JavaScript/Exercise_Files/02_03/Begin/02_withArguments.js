// Learning Functional Programming with Javascript
// Chapter 02, Video 03, Exercise 02

function add(x, y) {
  return x + y
}

function subtract(x, y) {
  return x - y
}
