// Learning Functional Programming with Javascript
// Chapter 02, Video 03, Exercise 03

function doIf(condition, func) {
  if (condition) {
    func()
  }
}
