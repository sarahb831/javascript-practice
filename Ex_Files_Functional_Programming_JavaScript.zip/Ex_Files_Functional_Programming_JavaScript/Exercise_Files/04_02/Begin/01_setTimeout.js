// Learning Functional Programming with Javascript
// Chapter 04, Video 02, Exercise 01
